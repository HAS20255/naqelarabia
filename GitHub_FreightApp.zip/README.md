# FreightApp

## 📦 Backend (Node.js)
1. تأكد من إعداد ملف `.env` في مجلد `backend/`
2. شغّل الخادم بـ:
```bash
cd backend
npm install
node server.js
```

## 🖥️ Admin Dashboard (React)
1. داخل مجلد `admin/`, أضف متغير البيئة:
```
REACT_APP_API_URL=https://freight-api.onrender.com
```
2. وارفعه على Vercel أو Netlify.
