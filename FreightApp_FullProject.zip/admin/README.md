# FreightApp Admin Dashboard
Instructions to run admin dashboard.