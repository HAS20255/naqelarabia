# FreightApp Backend
Instructions to run backend server.